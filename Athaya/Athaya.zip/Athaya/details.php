<?php include 'header.php' ?>

<div class="d-flex justify-content-center bg-dark text-white">
    
</div>

<?php include 'footer.php' ?>