<html>
<footer class="footer bg-dark text-white pt-5">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h5>About Us</h5>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec euismod lacus ac felis consectetur, in scelerisque metus tristique.</p>
      </div>
      <div class="col-md-6">
        <h5>Contact Us</h5>
        <p>123 Main Street, City, Country</p>
        <p>Email: info@example.com</p>
        <p>Phone: 123-456-7890</p>
      </div>
    </div>
  </div>
</footer>
</html>